// Samuel Noel
// 01/28/23


import java.util.Scanner;
 class Main {
  public static void main(String[] args) {
  int sum = 0;
  int posNum = 0;
  int negNum = 0;
  int input = 0;
  
  
  boolean flag = false;
   while (input > 0);
    {
      System.out.println("Please enter a integer:");
      input = scan.nextInt();
    }
    System.out.println("You entered " + posNum + " positive numbers.");
    System.out.println("You entered " + negNum + " negative numbers");
    double total = sum * 1.0 / (posNum + negNum);
    
    System.out.println("The average of your numbers is" + total);
      }
}